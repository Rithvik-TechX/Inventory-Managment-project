package com.inventory.database_system.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.inventory.database_system.entity.Category;

public interface CategoryRepository extends JpaRepository<Category, Long> {

}