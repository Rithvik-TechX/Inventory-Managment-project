package com.inventory.database_system.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.inventory.database_system.entity.Transaction;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {

}