package com.inventory.database_system.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.inventory.database_system.entity.Product;

public interface ProductRepository extends JpaRepository<Product, Long> {

}