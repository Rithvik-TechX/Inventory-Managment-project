package com.inventory.database_system.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.inventory.database_system.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {

}